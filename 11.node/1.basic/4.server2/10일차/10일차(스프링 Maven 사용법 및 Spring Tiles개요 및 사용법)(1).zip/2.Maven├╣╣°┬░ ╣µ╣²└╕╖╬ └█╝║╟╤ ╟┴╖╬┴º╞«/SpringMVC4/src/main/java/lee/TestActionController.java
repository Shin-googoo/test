package lee;

import javax.servlet.http.HttpServletRequest;//요청
import javax.servlet.http.HttpServletResponse;//응답

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

public class TestActionController implements Controller {

	 //  /index2.do->handleRequest()호출->처리결과(list3.jsp)
	@Override
	public ModelAndView handleRequest(HttpServletRequest request, 
			                                                HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("TestActionController의 handleRequst()호출됨");
		ModelAndView mav=new ModelAndView();//이동할페이지,화면에 데이터출력
		mav.setViewName("list3");//이동할페이지명만 지정=>경로?,확장자?
		//->viewResolver
		//모델2->request.setAttribute("키명",저장할값)<->request.getAttribute("키명")
		mav.addObject("greeting","스프링세상!!");//
		//request.setAttribute("greeting","스프링세상!!");
		return mav;//return "/list3.jsp"->viewResolver가 분리->/list3.jsp
	}
}


package kr.spring.tiles.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {  //  /index.do

	@RequestMapping("/index.do")
	public String process() { // ModelAndView 사용X->tiles에서 따로 불러처리
		//return "문자열(index)"==><definition name="index" template="/WEB-INF/tiles-view/template/layout.jsp">
		//                                                                  ==== 이름과 일치하는 이름을 찾아서 출력
		return "index";
	}
}

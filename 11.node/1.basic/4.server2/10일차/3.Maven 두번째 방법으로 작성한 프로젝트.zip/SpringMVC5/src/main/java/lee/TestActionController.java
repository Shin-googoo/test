package lee;

import java.util.Calendar;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TestActionController {

	/*
	 * public String hello()->return "home";  /home.jsp로 전환
	 * 이동하면서 데이터도 전달->ModelAndView
	 * 메서드->다른 컨트롤러 이용->redirect:/요청명령어를 이용->return "redirect:/요청명령어";
	 */
	@RequestMapping("/hello.do")
	public ModelAndView hello() {
		System.out.println("hello() 호출됨!!!");
		ModelAndView mav=new ModelAndView();
		mav.setViewName("hello");
		mav.addObject("greeting",getGreeting());//request.getAttribute("greeting")->${greeting}
		return mav;
	}
	
	private String getGreeting() {
		int hour=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);//시간대상수값 Calendar.시간대표시 상수
		if(hour >=6 && hour<=10) {
			return "좋은 아침입니다.";
		}else if(hour>=12 && hour<=15) {
			return "점심식사";
		}else if(hour>=18 && hour<=22) {
			return "저녁시간때";
		}
	  return "안녕하세요~";	
	}
}

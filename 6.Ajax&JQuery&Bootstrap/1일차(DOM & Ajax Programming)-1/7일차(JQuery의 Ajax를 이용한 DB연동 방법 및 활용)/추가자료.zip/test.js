/**
 * 자바스크립트파일 기술
 */
function call(param){
	return ("Hello,"+param)
}
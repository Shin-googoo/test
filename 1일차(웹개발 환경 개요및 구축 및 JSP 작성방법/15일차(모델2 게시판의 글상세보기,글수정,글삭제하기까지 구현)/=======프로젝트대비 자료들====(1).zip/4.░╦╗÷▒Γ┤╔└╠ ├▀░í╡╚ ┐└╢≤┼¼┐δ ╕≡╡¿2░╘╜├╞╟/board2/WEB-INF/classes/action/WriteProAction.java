package action;

import javax.servlet.http.*;

import lys.board.*;//������ �޼��� ȣ��
import java.sql.Timestamp;

public class WriteProAction implements CommandAction {
	public String requestPro(HttpServletRequest request,
			HttpServletResponse response) throws Throwable {
		
		    //writeForm.jsp->writePro.jsp(�ѱ�ó��)
		     request.setCharacterEncoding("euc-kr");
		 
		    BoardDataBean article = new BoardDataBean();
		  
		    article.setNum(Integer.parseInt(request.getParameter("num")));
		    article.setWriter(request.getParameter("writer"));
		    article.setEmail(request.getParameter("email"));
		    article.setSubject(request.getParameter("subject"));
		    article.setPasswd(request.getParameter("passwd"));
		    article.setReg_date(new Timestamp
	                            (System.currentTimeMillis()));
		    article.setRef(Integer.parseInt(request.getParameter("ref")));
		    article.setRe_step(Integer.parseInt(request.getParameter("re_step")));
		    article.setRe_level(Integer.parseInt(request.getParameter("re_level")));
		    article.setContent(request.getParameter("content"));
		    article.setIp(request.getRemoteAddr());
		    
		    //insertArticle()ȣ��
		    BoardDBMgr dbPro = new BoardDBMgr();
		    dbPro.insertArticle(article);
		  
		return "writePro.jsp";
	}
}

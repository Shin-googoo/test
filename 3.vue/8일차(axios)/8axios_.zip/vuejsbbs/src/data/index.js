export default [
    {
        writer:'홍길동',
        title:'게시판제목',
        content:'내용'
    },
    {
        writer:'임시',
        title:'게시판제목2',
        content:'내용2'
    },
    {
        writer:'테스트김',
        title:'게시판제목3',
        content:'내용3'
    },
]